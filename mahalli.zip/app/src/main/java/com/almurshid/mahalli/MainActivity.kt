package com.almurshid.mahalli

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var backend: GoBackend
    private lateinit var button: TextView
    private lateinit var status: TextView
    private var busy = false
    private var up = false

    private val tunnel = object : Tunnel {
        override fun getName() = "mahalli"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        up = try {
            backend.runningTunnelNames.contains("mahalli")
        } catch (e: Exception) {
            false
        }
        buildUi()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F172A"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        val title = TextView(this).apply {
            text = "محلي"
            textSize = 40f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "اتصالات المرشد"
            textSize = 18f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
        }
        button = TextView(this).apply {
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { toggle() }
        }
        val size = dp(200)
        val btnParams = LinearLayout.LayoutParams(size, size).apply {
            topMargin = dp(48)
            bottomMargin = dp(32)
        }
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#CBD5E1"))
            gravity = Gravity.CENTER
        }
        val note = TextView(this).apply {
            text = "مجاني بالكامل • حجب المحتوى الإباحي قدر الإمكان"
            textSize = 13f
            setTextColor(Color.parseColor("#64748B"))
            gravity = Gravity.CENTER
            setPadding(0, dp(40), 0, 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(button, btnParams)
        root.addView(status)
        root.addView(note)
        setContentView(root)
    }

    private fun render(message: String? = null) {
        val color = if (up) "#16A34A" else "#2563EB"
        button.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
        }
        button.text = if (up) "متصل\nاضغط للفصل" else "اضغط\nللاتصال"
        status.text = message ?: if (up) "الاتصال شغال" else "غير متصل"
    }

    private fun toggle() {
        if (busy) return
        if (up) {
            busy = true
            render("جاري الفصل...")
            thread {
                try {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    up = false
                    runOnUiThread { render() }
                } catch (e: Exception) {
                    runOnUiThread { render("خطأ: ${e.message}") }
                } finally {
                    busy = false
                }
            }
        } else {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                startActivityForResult(intent, 1)
            } else {
                connect()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) connect()
    }

    private fun connect() {
        if (busy) return
        busy = true
        render("جاري الاتصال...")
        thread {
            try {
                val config = loadConfig()
                backend.setState(tunnel, Tunnel.State.UP, config)
                up = true
                runOnUiThread { render() }
            } catch (e: Exception) {
                runOnUiThread { render("فشل الاتصال: ${e.message}") }
            } finally {
                busy = false
            }
        }
    }

    private fun loadConfig(): Config {
        val prefs = getSharedPreferences("mahalli", MODE_PRIVATE)
        if (!prefs.contains("priv")) register()
        val text = """
            [Interface]
            PrivateKey = ${prefs.getString("priv", "")}
            Address = ${prefs.getString("v4", "")}/32, ${prefs.getString("v6", "")}/128
            DNS = 1.1.1.3, 1.0.0.3, 2606:4700:4700::1113, 2606:4700:4700::1003
            MTU = 1280

            [Peer]
            PublicKey = ${prefs.getString("peer", "")}
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = 162.159.192.1:2408
        """.trimIndent()
        return Config.parse(ByteArrayInputStream(text.toByteArray()))
    }

    private fun register() {
        val keys = KeyPair()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.000'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val body = JSONObject()
            .put("key", keys.publicKey.toBase64())
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", fmt.format(Date()))
            .put("type", "Android")
            .put("model", "PC")
            .put("locale", "en_US")

        val conn = URL("https://api.cloudflareclient.com/v0a2158/reg")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("CF-Client-Version", "a-6.3-2158")
        conn.setRequestProperty("User-Agent", "okhttp/3.12.1")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        if (code !in 200..299) throw RuntimeException("تسجيل الخدمة فشل ($code)")
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val cfg = json.getJSONObject("config")
        val peer = cfg.getJSONArray("peers").getJSONObject(0)
        val addrs = cfg.getJSONObject("interface").getJSONObject("addresses")

        getSharedPreferences("mahalli", MODE_PRIVATE).edit()
            .putString("priv", keys.privateKey.toBase64())
            .putString("peer", peer.getString("public_key"))
            .putString("v4", addrs.getString("v4"))
            .putString("v6", addrs.getString("v6"))
            .apply()
    }
}
